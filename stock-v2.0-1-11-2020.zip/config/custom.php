<?php

return [

    'items_per_page'            => 10000 ,
    'token_expire_in'          	=> 10 ,
    'refresh_token_expire_in'  	=> 10 ,
];
