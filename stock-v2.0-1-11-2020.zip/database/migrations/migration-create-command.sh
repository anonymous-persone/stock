php ../../artisan make:migration create_regions_table
php ../../artisan make:migration create_subregions_table
php ../../artisan make:migration create_traders_table
php ../../artisan make:migration create_selling_deals_table
php ../../artisan make:migration create_purchasing_deals_table
php ../../artisan make:migration create_collecting_deals_table