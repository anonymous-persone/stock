<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property string $title_en
 * @property string $title_ar
 * @property string $created_at
 * @property string $updated_at
 * @property Subregion[] $subregions
 */
class Region extends Model
{
    use \EloquentFilter\Filterable;
    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['title_en', 'title_ar', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function subregions()
    {
        return $this->hasMany('App\Models\Subregion');
    }

    protected $appends = ['boxes_sold_out', 'money_indebtedness'];

    public function getMoneyIndebtednessAttribute()
    {
        $arr = \DB::select("
            SELECT /*regions.*, res.* */ res.money_indebtedness

            FROM regions, subregions,

            (select traders.subregion_id, sum(traders.money_indebtedness) as money_indebtedness From traders Group by traders.subregion_id) as res

            WHERE regions.id = subregions.region_id and subregions.id = res.subregion_id and regions.id = $this->id

            ");
        return array_sum(array_column($arr,'money_indebtedness'));
    }
    
    public function getBoxesSoldOutAttribute()
    {

        $arr = \DB::select("
            SELECT /*regions.*, res.**/  res.boxes_sold_out
            FROM regions, subregions, traders, 

            (select selling_deals.trader_id, sum(selling_deals.boxes_count) as boxes_sold_out From selling_deals Group by selling_deals.trader_id) as res

            WHERE regions.id = subregions.region_id and subregions.id = traders.subregion_id and  traders.id = res.trader_id and regions.id = $this->id

            ");
        return array_sum(array_column($arr,'boxes_sold_out'));


        /*dd($this->whereHas('subregions', function($query){
            return $query->whereHas('traders', function($query){
                return $query->whereHas('sellingDeals', function($query){
                    return $query->sum('boxes_count');
                });
            });
        })->get());
        return  dd($this->join('subregions', 'regions.id', 'subregions.region_id')
                    ->join('traders', 'subregions.id', 'traders.subregion_id')
                    ->join('selling_deals', 'traders.id', 'selling_deals.trader_id')
                    ->selectRaw('sum(boxes_count)')->get());*/
    }

    /*'SELECT r1.*, res.* 
    FROM `regions`as r1, regions as r2, traders, 

    (select selling_deals.trader_id, sum(selling_deals.boxes_count) as boxes_count From selling_deals Group by selling_deals.trader_id) as res

    WHERE r1.id = r2.parent_id and r2.id = traders.region_id and  traders.id = res.trader_id and r1.`parent_id` IS null'*/


    /*
    SELECT regions.*, res.* 
    FROM regions, subregions, traders, 

    (select selling_deals.trader_id, sum(selling_deals.boxes_count) as boxes_count From selling_deals Group by selling_deals.trader_id) as res

    WHERE regions.id = subregions.region_id and subregions.id = traders.subregion_id and  traders.id = res.trader_id and regions.id = 2
    */
}
