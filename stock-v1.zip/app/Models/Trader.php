<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $subregion_id
 * @property string $name
 * @property string $phone
 * @property float $money_indebtedness
 * @property int $boxes_indebtedness
 * @property string $created_at
 * @property string $updated_at
 * @property Subregion $subregion
 * @property SellingDeal[] $sellingDeals
 */
class Trader extends Model
{
    use \EloquentFilter\Filterable;
    
    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['subregion_id', 'name', 'phone', 'money_indebtedness', 'boxes_indebtedness', 'created_at', 'updated_at'];

    protected $hidden = ['sellingDeals', 'collectingDeals'];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function subregion()
    {
        return $this->belongsTo('App\Models\Subregion');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function sellingDeals()
    {
        return $this->hasMany('App\Models\SellingDeal');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function collectingDeals()
    {
        return $this->hasMany('App\Models\CollectingDeal');
    }

    protected $appends = ['overdue_indebtedness'];

    public function getOverdueIndebtednessAttribute()
    {
        $sellingDeal = $this->sellingDeals->last();
        $collectingDeal = $this->collectingDeals->last();

        return $sellingDeal && $collectingDeal ?
                $sellingDeal->created_at->diffInDays(
                    $collectingDeal->created_at
                ) : 0;
    }

    public function calcIndebtednesses($moneyIndebtedness, $boxesIndebtedness, $operator = '+')
    {
        switch($operator) {
            case "+":
                $this->money_indebtedness += $moneyIndebtedness;
                $this->boxes_indebtedness += $boxesIndebtedness;
                break;
            case "-":
                $this->money_indebtedness -= $moneyIndebtedness;
                $this->boxes_indebtedness -= $boxesIndebtedness;
                break;
        }
        $this->save();
    }
}
