<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $region_id
 * @property string $title_en
 * @property string $title_ar
 * @property string $created_at
 * @property string $updated_at
 * @property Region $region
 * @property Trader[] $traders
 */
class Subregion extends Model
{
    use \EloquentFilter\Filterable;
    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['region_id', 'title_en', 'title_ar', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function region()
    {
        return $this->belongsTo('App\Models\Region');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function traders()
    {
        return $this->hasMany('App\Models\Trader');
    }

    protected $appends = ['money_indebtedness', 'boxes_indebtedness',];
    
    public function getMoneyIndebtednessAttribute()
    {
        return  $this->traders()->get()
                ->transform(function($trader, $key){
                    return $trader->money_indebtedness;
                })->sum();
    }

    public function getBoxesIndebtednessAttribute()
    {
        return  $this->traders()->get()
                ->transform(function($trader, $key){
                    return $trader->boxes_indebtedness;
                })->sum();
    }
}
