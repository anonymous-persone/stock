<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $trader_id
 * @property int $boxes_indebtedness_before
 * @property int $boxes_count
 * @property int $boxes_indebtedness_after
 * @property float $money_indebtedness_before
 * @property float $paid
 * @property float $money_indebtedness_after
 * @property string $created_at
 * @property string $updated_at
 * @property Trader $trader
 */
class CollectingDeal extends Model
{
    use \EloquentFilter\Filterable;
    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['trader_id', 'boxes_indebtedness_before', 'boxes_count', 'boxes_indebtedness_after', 'money_indebtedness_before', 'paid', 'money_indebtedness_after', 'created_at', 'updated_at'];

    protected $hidden = ['trader'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function trader()
    {
        return $this->belongsTo('App\Models\Trader');
    }
}
