<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CollectingDealRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        // check if update request or store request
        $id =  $this->collecting_deal ?? 'NULL';

        return [
        	'trader_id' => ['required', 'exists:traders,id'],
            'boxes_indebtedness_before' => [
            	'required',
            	'integer',
            	'min:0', 
            	"exists:traders,boxes_indebtedness,id,$this->trader_id"
            ],
            'boxes_count' => ['required', 'integer', 'min:0', 'lte:boxes_indebtedness_before'],
            'boxes_indebtedness_after' => [
            	'required',
            	'integer',
            	'min:0',
            	'in:' . ($this->boxes_indebtedness_before - $this->boxes_count)
            ],
            'money_indebtedness_before' => [
            	'required',
            	'numeric',
            	'min:0',
            	"exists:traders,money_indebtedness,id,$this->trader_id"
            ],
            'paid' => ['required', 'numeric', 'min:0','lte:money_indebtedness_before'],
            'money_indebtedness_after' => [
            	'required',
            	'numeric',
            	'min:0',
            	'in:' . ($this->money_indebtedness_before - $this->paid)
            ],
        ];
    }
}
